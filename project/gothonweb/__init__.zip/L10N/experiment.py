#from I18NDate import I18NDateFind
import I18NDate

print I18NDate.I18NDateFind()

print I18NDate.I18NTimeFind()


#https://www.programcreek.com/python/example/1707/locale.getlocale
#https://docs.python.org/2/library/locale.html
#https://www.quora.com/How-does-one-write-a-Python-library

#Presentation
'''https://www.slideshare.net/onceuponatimeforever/lets-read-code
    https://www.pytennessee.org/schedule/presentation/90/ '''


